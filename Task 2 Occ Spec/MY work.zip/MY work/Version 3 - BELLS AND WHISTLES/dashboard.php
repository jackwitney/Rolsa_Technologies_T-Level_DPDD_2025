<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Rolsa Technologies Dashboard</title>
</head>
<body>
<!-- Header -->
<header>
    <div class="logo">Rolsa Technologies Dashboard, [User]</div>
    <div class="header-buttons">
        <a href="book_appt.php"><button class="nav-btn">Book Appointment</button></a>
        <a href="calc.php"><button class="nav-btn">Carbon Calculator</button></a>
        <a href="contact_us.php"><button class="nav-btn">Contact Us</button></a>
        <a href="logout.php"><button class="nav-btn">Logout</button></a>
    </div>
    <img src="assets/Rolsa_Tech_Logo_Transparent.png" alt="Rolsa Logo" class="company-logo">
</header>

<!-- Main Content -->
<main>
    <!-- Appointments Section -->
    <div class="appointments-container">
        <!-- First Appointment Card -->
        <div class="appointment-card">
            <div class="appointment-details">
                <p><strong>Date:</strong> 15/03/2025</p>
                <p><strong>Type:</strong> Consultation</p>
            </div>
            <div class="appointment-notes">
                <p>Notes: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id ullamcorper lectus. Vivamus.</p>
            </div>
            <div class="appointment-actions">
                <button class="btn rearrange-btn">Rearrange</button>
                <button class="btn add-notes-btn">Add Notes</button>
                <button class="btn cancel-btn">Cancel</button>
            </div>
        </div>

        <!-- Second Appointment Card -->
        <div class="appointment-card">
            <div class="appointment-details">
                <p><strong>Date:</strong> 19/04/2025</p>
                <p><strong>Type:</strong> Installation</p>
            </div>
            <div class="appointment-notes">
                <p>Notes: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id ullamcorper lectus. Vivamus.</p>
            </div>
            <div class="appointment-actions">
                <button class="btn rearrange-btn">Rearrange</button>
                <button class="btn add-notes-btn">Add Notes</button>
                <button class="btn cancel-btn">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Usage Stats Section -->
    <div class="usage-container">
        <div class="chart-container">
            <img src="carbon-footprint-chart.png" alt="Carbon Footprint Chart" class="chart-image">
            <!-- If you don't have the actual chart image, you can use a placeholder and replace it later -->
            <!-- <div class="chart-placeholder">
                <p>Total Carbon Footprint: 1.25kg CO2 /kW</p>
                <p>Average User</p>
            </div> -->
        </div>

        <div class="usage-stats">
            <h2>Your Usage Rates this Year</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id ullamcorper lectus. Vivamus consequat mauris sed diam porta pellentesque. Aenean eu urna laoreet, tempor risus ac, euismod lectus. Maecenas fermentum feugiat dolor, non finibus augue efficitur ut. Proin congue sem orci. Donec porttitor metus et elit lobortis, in eleifend massa mattis. Maecenas scelerisque fringilla massa ut viverra. Fusce ac mattis elit, nec congue erat. Nullam sit amet sollicitudin urna. Maecenas tristique faucibus lectus id aliquet. Aliquam rhoncus at justo sit amet luctus. Quisque imperdiet eleifend risus. Nulla eget sollicitudin velit. Suspendisse ultrices metus nibh, ut pulvinar purus dapibus ut.</p>
        </div>
    </div>
</main>
</body>
</html>