<?php

session_start();
require_once 'nav.php';
echo"welcome to admin dashboard";
echo "<br>";


//header("location:admin_add.php");
