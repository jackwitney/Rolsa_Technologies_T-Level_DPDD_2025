<?php
require_once 'user_nav.php';


// Since Dashboard is a predominantly static page it will be a version 2 problem